# MyWeather

A simple weather data fetching package using OpenWeather API.

## Installation

```sh
pip install myweather